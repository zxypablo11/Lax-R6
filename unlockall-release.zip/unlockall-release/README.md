# unlockall — Rainbow Six Siege

## setup

1. Turn off **Memory Integrity** (Windows Security → Device security → Core isolation). Reboot.
2. Right-click **`setup.cmd`** → **Run as administrator**.
   Fetches the kernel symbol file, loads the driver, starts the cheat.
3. Start Rainbow Six Siege (DX11).
4. **INSERT** = menu. **END** = close.

Run `setup.cmd` once after every PC restart — the driver does not survive a
reboot. Running it again while the driver is already loaded is a no-op, so it is
safe to double-click twice.

No test signing. `bcdedit /set testsigning on` is not used and is not needed.

## files

```
setup.cmd              does everything (use this one)
get-symbols.ps1        downloads the kernel symbol file
load-driver.cmd        load driver only
unload-driver.cmd      put DSE back, reboot to unload
unlockall.exe          cheat + overlay
driver\lifus.sys       kernel driver
loader\loader.exe      BYOVD DSE-bypass loader
loader\sec-rva.ps1     resolves nt!SeCiCallbacks rva      (-sec)
loader\safe-rva.ps1    resolves the return-success thunk  (-safe)
```

## how the load works

`loader.exe` stages the signed-but-vulnerable `RTCore64.sys`, uses its kernel
read/write to repoint one entry in `nt!SeCiCallbacks` at a function of our
choosing, starts the driver service, then puts the original entry back.

Three things are different from the stock bundle, and all three are required:

1. **Both RVAs are passed explicitly — `-sec` and `-safe`.**
   The loader only resolves RVAs from the PDB when *neither* flag is given.
   Passing just one makes it fall back to a baked-in constant for the other, and
   that constant (`0xF04740`) is wrong for this kernel: the read comes back as
   nine zero slots and the loader refuses with
   `secicallbacks rva 0x... is wrong for this windows build`.

2. **`-sec` is the table address, not the slot.**
   `SeCiCallbacks` is a table of pointers; the loader patches slot **+0x20**,
   which is the callback `MiValidateSectionCreate` invokes through
   `guard_dispatch_icall` (`nt+0x9407C5` loads it). That is the gate that
   rejects unsigned driver images, so `-sec` is the table itself.

3. **`-safe` must point at a function that returns `STATUS_SUCCESS`.**
   This is the actual bug in the stock bundle. Stock leaves the loader's default,
   `ZwFlushInstructionCache`, in that slot. Called with the image loader's
   argument list it returns a failure status, so section creation records a
   failed validation and the driver entry is refused — surfaced as
   `ERROR_FAILED_DRIVER_ENTRY` (647), after the signature check has already been
   bypassed (577 → 647).
   `loader\safe-rva.ps1` walks the image's own load-config `GuardCFFunctionTable`
   and returns a real CFG-registered function whose entire body is
   `xor eax,eax / ret` in nonpaged `.text`. Because the slot is reached through
   `guard_dispatch_icall`, a bare mid-function gadget is not safe — it fails the
   CFG check and bugchecks instead of loading. A registered function passes the
   check and returns `STATUS_SUCCESS` for any argument list.

Additionally `load-driver.cmd` stops Vanguard (`vgk`), BattlEye
(`BEDaisy`/`BEService`) and Sentinel (`sen_driver`/`sen_service`) before the
load. They restart with their game, so this is per-run, not permanent.

### the rva values

Everything is derived from the `ntoskrnl.exe` on the machine, so a kernel update
does not need a new build of this pack:

| flag | source |
|---|---|
| `-sec` | public kernel PDB, symbol `SeCiCallbacks`; falls back to a build-keyed table in `loader\sec-rva.ps1` |
| `-safe` | the image's own CFG function table — first `.text` entry that is `xor eax,eax / ret` |

Verified values for kernel `10.0.26100.9711` (Windows 11 25H2, build 26200):

```
-sec  0xF04E40      patch lands at SeCiCallbacks+0x20
-safe 0x48FDC0      SC_DEVICE::GetStoragePropertyPost, body = xor eax,eax / ret
```

If the PDB is not cached and there is no network, `sec-rva.ps1` uses the table.
For a kernel build not in the table it exits with the build number — add a row.

## if it stops

| step fails | fix |
|---|---|
| step 1 symbol file | falls through to the build table, nothing to do. Only matters on a kernel build newer than the table |
| step 2, `error 183` / `1072` on rtcore64 | a previous attempt left the RTCore64 driver object resident; only a reboot releases it. Reboot, run `setup.cmd` again |
| step 2, `is wrong for this windows build` | the read at `SeCiCallbacks+0x20` came back empty — unknown kernel build. Send `%TEMP%\unlockall-load.log` and `ver` |
| step 2, `error 647` | callback patched and verified but the entry was still refused. Send `%TEMP%\unlockall-load.log` |
| step 2, `error 577` | the patch did not hold — a live anti-cheat driver reverted it. Reboot with the game closed |
| step 3 cheat | game must be running on DX11 |

One attempt per boot. The loader deletes the RTCore64 service without stopping
the driver, so the driver object outlives the script: a second attempt in the
same session fails at the bootstrap step with `error 183`, not at your driver.
Successful loads are detected and skipped.

Anything about `loader.exe` being blocked: allow it in Defender, it is unsigned.

Log for reporting: `%LocalAppData%\unlockall\logs\unlockall-diagnostic-latest.zip`
Loader log: `%TEMP%\unlockall-load.log`
