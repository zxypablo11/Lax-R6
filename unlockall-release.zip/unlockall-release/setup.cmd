@echo off
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

for %%F in (driver\lifus.sys loader\loader.exe unlockall.exe get-symbols.ps1) do (
    if not exist "%%F" (
        echo [!] missing file: %%F
        pause
        exit /b 1
    )
)

echo ==============================
echo  step 1 - kernel symbol file
echo ==============================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0get-symbols.ps1"
if errorlevel 1 (
    echo.
    echo [!] symbol file not downloaded - carrying on anyway. the rva lookup
    echo [!] falls back to a build table, so this only matters on a kernel
    echo [!] build the table does not know. use the browser link above and
    echo [!] run setup.cmd again if step 2 reports an unknown build.
    timeout /t 3 >nul
)

echo.
echo ==============================
echo  step 2 - loading driver
echo ==============================
call "%~dp0load-driver.cmd" --no-pause
if errorlevel 1 (
    echo.
    echo [!] driver load failed - see the lines above
    pause
    exit /b 1
)

echo.
echo ==============================
echo  step 3 - starting cheat
echo ==============================
start "" "%~dp0unlockall.exe"

echo.
echo [+] done. press INSERT in game for the menu, END to close it.
timeout /t 5 >nul
