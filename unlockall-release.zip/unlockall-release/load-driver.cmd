@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "NOPAUSE="
if /i "%~1"=="--no-pause" set "NOPAUSE=1"

rem ---- elevation -------------------------------------------------------------
net session >nul 2>&1
if errorlevel 1 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

for %%F in (driver\lifus.sys loader\loader.exe loader\safe-rva.ps1 loader\sec-rva.ps1) do (
    if not exist "%%F" (
        echo [!] missing file: %%F
        goto :fail
    )
)

set "LOG=%TEMP%\unlockall-load.log"

rem ---- already loaded? ------------------------------------------------------
rem setup.cmd re-runs this file, and the driver cannot be started twice in one
rem session, so short-circuit when it is already up.
sc query lifus 2>nul | findstr /i "RUNNING" >nul
if not errorlevel 1 (
    echo [*] lifus is already loaded this session - nothing to do
    set "RC=0"
    goto :finish
)

rem ---- conflicting kernel anti-cheat -----------------------------------------
rem Vanguard polices DSE and can revert the loader's patch behind its back;
rem BattlEye and Sentinel sit in the same path. They all restart with their game,
rem so this is per-run, not permanent.
echo [*] stopping resident anti-cheat drivers
for %%S in (vgk vgc BEService BEDaisy sen_service sen_driver) do (
    sc stop %%S >nul 2>&1
)
timeout /t 3 /nobreak >nul

rem ---- the two RVAs the loader needs ----------------------------------------
rem -sec is nt!SeCiCallbacks itself; the loader patches slot +0x20, which is the
rem image-validation callback MiValidateSectionCreate calls.
rem -safe must be a CFG-registered "return STATUS_SUCCESS" function, because that
rem slot is reached through guard_dispatch_icall.
rem Both must be passed: giving the loader only one of them makes it skip PDB
rem resolution for the other and fall back to a baked-in RVA that is wrong for
rem this build.
set "SEC="
for /f "usebackq delims=" %%R in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0loader\sec-rva.ps1"`) do set "SEC=%%R"
if not defined SEC (
    echo [!] could not resolve nt!SeCiCallbacks rva from ntoskrnl.exe
    goto :fail
)

set "SAFE="
for /f "usebackq delims=" %%R in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0loader\safe-rva.ps1"`) do set "SAFE=%%R"
if not defined SAFE (
    echo [!] could not resolve a return-success thunk rva from ntoskrnl.exe
    goto :fail
)

echo [*] SeCiCallbacks      %SEC%  ^(patch target +0x20^)
echo [*] success thunk      %SAFE%

rem ---- load -----------------------------------------------------------------
echo [*] loading lifus.sys
"loader\loader.exe" load "%~dp0driver\lifus.sys" -sec %SEC% -safe %SAFE% -y > "%LOG%" 2>&1
type "%LOG%"

rem the loader prints this only when StartService on the target driver succeeded
findstr /c:"[+] target driver loaded successfully" "%LOG%" >nul
if not errorlevel 1 (
    echo.
    echo [+] driver loaded - continue with step 3 in setup.cmd
    set "RC=0"
    goto :finish
)

findstr /c:"startservice rtcore64 failed (error 183)" "%LOG%" >nul
if not errorlevel 1 (
    echo.
    echo [!] the RTCore64 driver object from an earlier run is still resident.
    echo [!] only a reboot releases it. reboot, then run this again.
    goto :fail
)

findstr /c:"createservice rtcore64 failed (error 1072)" "%LOG%" >nul
if not errorlevel 1 (
    echo.
    echo [!] the RTCore64 service is marked for deletion from an earlier run.
    echo [!] reboot, then run this again.
    goto :fail
)

findstr /c:"is wrong for this windows build" "%LOG%" >nul
if not errorlevel 1 (
    echo.
    echo [!] the read at SeCiCallbacks+0x20 ^(%SEC% + 0x20^) came back empty.
    echo [!] ntoskrnl.exe on this machine is not the build the rva was resolved
    echo [!] for. send %LOG% and the output of "ver" so the table gets a row.
    goto :fail
)

findstr /c:"safe function rva" "%LOG%" >nul
if not errorlevel 1 (
    echo.
    echo [!] the loader rejected the -safe rva ^(%SAFE%^) - it must land inside
    echo [!] the .text section of the running ntoskrnl.exe. send %LOG%.
    goto :fail
)

findstr /c:"error 647" "%LOG%" >nul
if not errorlevel 1 (
    echo.
    echo [!] the image validation callback was patched and verified, but the
    echo [!] kernel still refused the driver entry ^(647^). send %LOG%.
    goto :fail
)

findstr /c:"error 577" "%LOG%" >nul
if not errorlevel 1 (
    echo.
    echo [!] the patch did not hold - a resident anti-cheat driver reverted it.
    echo [!] reboot with the game closed, then run this again. send %LOG%.
    goto :fail
)

echo [!] driver did not load - see the loader output above
goto :fail

:fail
set "RC=1"

:finish
if defined NOPAUSE exit /b %RC%
if not "%RC%"=="0" pause
exit /b %RC%
