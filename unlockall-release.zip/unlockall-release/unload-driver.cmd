@echo off
setlocal
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
    echo [!] run this as administrator
    pause
    exit /b 1
)

echo [*] restoring DSE from saved state
"loader\loader.exe" restore -y

echo.
echo [*] driver stays resident until reboot.
echo [*] reboot now to fully unload it.
pause
