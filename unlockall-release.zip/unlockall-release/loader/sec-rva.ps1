<#
    sec-rva.ps1 - resolve nt!SeCiCallbacks RVA for the running ntoskrnl.exe.

    Why both -sec and -safe have to be passed to loader.exe:

      loader.exe resolves both RVAs from the PDB only when NEITHER flag is given
      (dumpbin: the two "provided" flags are tested at 0x1400010E8 / 0x1400010F0
      and both nonzero skips the resolver). Pass -safe alone and the baked-in
      default sec RVA 0xF04740 is used, which reads nine zero qwords on this
      build - and the loader then refuses with
      "secicallbacks rva 0x... is wrong for this windows build".

      The loader patches kernel_base + sec + 0x20. That +0x20 is not arbitrary:
      SeCiCallbacks+0x20 is the image-validation callback that
      MiValidateSectionCreate calls (0x140009407C5 -> guard_dispatch_icall with
      rax loaded from SeCiCallbacks+0x20). So -sec is the address of the table
      itself, and the slot that gates DSE for image mapping is +0x20.

    Resolution order:
      1. public PDB via dbghelp (SeCiCallbacks is present in ntkrnlmp.pdb)
      2. build-keyed table below, when the PDB is not cached and there is no
         network. Add a row when a new kernel build shows up.

    Prints the RVA as 0x-hex on stdout. Exit code 1 when it cannot resolve.
#>
[CmdletBinding()]
param(
    [string]$KernelImage = (Join-Path $env:SystemRoot 'System32\ntoskrnl.exe'),
    [string]$SymbolPath  = 'C:\ProgramData\dbg\sym',
    [switch]$NoSymbols
)

$ErrorActionPreference = 'Stop'

# ---- build-keyed fallback ---------------------------------------------------
# key: FileVersion of ntoskrnl.exe (major.minor.build.revision)
# value: RVA of nt!SeCiCallbacks
$KnownBuilds = @{
    '10.0.26100.9711' = 0x00F04E40
}

if (-not ('SecRvaSymbols' -as [type])) {
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public static class SecRvaSymbols
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct SYMBOL_INFO
    {
        public uint   SizeOfStruct;
        public uint   TypeIndex;
        public ulong  Reserved1;
        public ulong  Reserved2;
        public uint   Index;
        public uint   Size;
        public ulong  ModBase;
        public uint   Flags;
        public ulong  Value;
        public ulong  Address;
        public uint   Register;
        public uint   Scope;
        public uint   Tag;
        public uint   NameLen;
        public uint   MaxNameLen;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1024)]
        public byte[] Name;
    }

    public delegate bool EnumCallback(IntPtr info, uint size, IntPtr context);

    [DllImport("dbghelp.dll", SetLastError = true)]
    static extern bool SymInitialize(IntPtr hProcess, string UserSearchPath, bool InvadeProcess);

    [DllImport("dbghelp.dll", SetLastError = true)]
    static extern bool SymSetSearchPath(IntPtr hProcess, string SearchPath);

    [DllImport("dbghelp.dll", SetLastError = true, CharSet = CharSet.Ansi)]
    static extern ulong SymLoadModuleEx(IntPtr hProcess, IntPtr hFile, string ImageName,
                                        string ModuleName, ulong BaseOfDll, uint DllSize,
                                        IntPtr Data, uint Flags);

    [DllImport("dbghelp.dll", SetLastError = true, CharSet = CharSet.Ansi)]
    static extern bool SymEnumSymbols(IntPtr hProcess, ulong BaseOfDll, string Mask,
                                      EnumCallback cb, IntPtr UserContext);

    [DllImport("dbghelp.dll", SetLastError = true)]
    static extern bool SymCleanup(IntPtr hProcess);

    public static uint? Resolve(string imagePath, string symbolPath, string symbol)
    {
        IntPtr process = new IntPtr(-1);
        if (!SymInitialize(process, symbolPath, false))
            return null;
        try
        {
            SymSetSearchPath(process, symbolPath);

            ulong modBase = SymLoadModuleEx(process, IntPtr.Zero, imagePath, null, 0, 0, IntPtr.Zero, 0);
            if (modBase == 0)
                return null;

            uint found = 0;
            bool have = false;

            EnumCallback cb = delegate (IntPtr info, uint size, IntPtr ctx)
            {
                SYMBOL_INFO si = (SYMBOL_INFO)Marshal.PtrToStructure(info, typeof(SYMBOL_INFO));
                string name = System.Text.Encoding.ASCII.GetString(si.Name, 0, (int)si.NameLen);
                if (name == symbol)
                {
                    found = (uint)(si.Address - modBase);
                    have = true;
                    return false;
                }
                return true;
            };

            SymEnumSymbols(process, modBase, symbol, cb, IntPtr.Zero);
            return have ? (uint?)found : null;
        }
        finally
        {
            SymCleanup(process);
        }
    }
}
'@ -ReferencedAssemblies 'System.dll'
}

if (-not (Test-Path -LiteralPath $KernelImage)) {
    Write-Error "kernel image not found: $KernelImage"
    exit 1
}

$vi = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($KernelImage)
$buildKey = '{0}.{1}.{2}.{3}' -f $vi.FileMajorPart, $vi.FileMinorPart, $vi.FileBuildPart, $vi.FilePrivatePart

$rva = $null
if (-not $NoSymbols) {
    try {
        # plain directory first (get-symbols.ps1 writes the store layout there and
        # dbghelp reads it without symsrv.dll), symbol server second
        $searchPath = "$SymbolPath;srv*$SymbolPath*https://msdl.microsoft.com/download/symbols"
        $rva = [SecRvaSymbols]::Resolve($KernelImage, $searchPath, 'SeCiCallbacks')
    } catch {
        $rva = $null
    }
}

if ($null -eq $rva) {
    Write-Verbose "symbol lookup failed, using the build table"
    if ($KnownBuilds.ContainsKey($buildKey)) {
        $rva = [uint32]$KnownBuilds[$buildKey]
    }
}

if ($null -eq $rva) {
    Write-Error ("no SeCiCallbacks rva for kernel build {0} - PDB unavailable and the build is not in the table" -f $buildKey)
    exit 1
}

'0x{0:X}' -f [uint32]$rva
