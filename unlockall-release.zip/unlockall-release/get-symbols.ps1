# Fetches the kernel symbol file the loader needs, using normal Windows download
# paths instead of the loader's own WinHTTP client. Reads the pdb signature
# straight out of ntoskrnl.exe, so nothing needs to be typed in by hand.

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls

function Get-PdbSignature([string]$path) {
    $bytes = [IO.File]::ReadAllBytes($path)
    if ([BitConverter]::ToUInt16($bytes, 0) -ne 0x5A4D) { throw 'not a PE file' }
    $pe = [BitConverter]::ToInt32($bytes, 0x3C)
    if ([BitConverter]::ToUInt32($bytes, $pe) -ne 0x00004550) { throw 'not a PE file' }

    $opt = $pe + 24
    $magic = [BitConverter]::ToUInt16($bytes, $opt)
    $dirBase = if ($magic -eq 0x20B) { $opt + 112 } else { $opt + 96 }
    $sections = $opt + [BitConverter]::ToUInt16($bytes, $pe + 20)
    $sectionCount = [BitConverter]::ToUInt16($bytes, $pe + 6)

    $debugRva = [BitConverter]::ToUInt32($bytes, $dirBase + 6 * 8)
    $debugSize = [BitConverter]::ToUInt32($bytes, $dirBase + 6 * 8 + 4)
    if ($debugRva -eq 0 -or $debugSize -eq 0) { throw 'no debug directory' }

    $debugOffset = -1
    for ($i = 0; $i -lt $sectionCount; $i++) {
        $s = $sections + $i * 40
        $va = [BitConverter]::ToUInt32($bytes, $s + 12)
        $vs = [BitConverter]::ToUInt32($bytes, $s + 8)
        if ($debugRva -ge $va -and $debugRva -lt ($va + $vs)) {
            $debugOffset = [BitConverter]::ToUInt32($bytes, $s + 20) + ($debugRva - $va)
            break
        }
    }
    if ($debugOffset -lt 0) { throw 'debug directory not mapped' }

    for ($i = 0; $i -lt [int]($debugSize / 28); $i++) {
        $e = $debugOffset + $i * 28
        if ([BitConverter]::ToUInt32($bytes, $e + 12) -ne 2) { continue }
        $cv = [BitConverter]::ToUInt32($bytes, $e + 24)
        if ($cv -le 0 -or ($cv + 24) -gt $bytes.Length) { continue }
        if ([BitConverter]::ToUInt32($bytes, $cv) -ne 0x53445352) { continue }

        $d1 = [BitConverter]::ToUInt32($bytes, $cv + 4)
        $d2 = [BitConverter]::ToUInt16($bytes, $cv + 8)
        $d3 = [BitConverter]::ToUInt16($bytes, $cv + 10)
        $age = [BitConverter]::ToUInt32($bytes, $cv + 20)
        $sb = New-Object Text.StringBuilder
        [void]$sb.Append($d1.ToString('X8'))
        [void]$sb.Append($d2.ToString('X4'))
        [void]$sb.Append($d3.ToString('X4'))
        for ($b = 0; $b -lt 8; $b++) { [void]$sb.Append($bytes[$cv + 12 + $b].ToString('X2')) }
        [void]$sb.Append($age.ToString('X'))
        return @{ Name = 'ntkrnlmp.pdb'; Signature = $sb.ToString() }
    }
    throw 'codeview record not found'
}

function Get-Remote([string]$url, [string]$dest) {
    foreach ($method in @('curl', 'web', 'bits')) {
        try {
            switch ($method) {
                'curl' {
                    $p = Start-Process -FilePath 'curl.exe' -ArgumentList @('-L', '--fail', '--silent', '--show-error',
                        '--max-time', '600', '-o', $dest, $url) -Wait -PassThru -NoNewWindow
                    if ($p.ExitCode -ne 0) { throw "curl exit $($p.ExitCode)" }
                }
                'web' {
                    $old = $ProgressPreference
                    $ProgressPreference = 'SilentlyContinue'
                    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -TimeoutSec 600
                    $ProgressPreference = $old
                }
                'bits' {
                    Import-Module BitsTransfer -ErrorAction Stop
                    Start-BitsTransfer -Source $url -Destination $dest -ErrorAction Stop
                }
            }
            if ((Test-Path $dest) -and (Get-Item $dest).Length -gt 1000000) {
                Write-Host "[+] downloaded with $method"
                return $true
            }
            Remove-Item $dest -Force -ErrorAction SilentlyContinue
            throw 'file too small'
        } catch {
            Write-Host "[-] $method failed: $($_.Exception.Message)"
            Remove-Item $dest -Force -ErrorAction SilentlyContinue
        }
    }
    return $false
}

$ntos = Join-Path $env:SystemRoot 'System32\ntoskrnl.exe'
$info = Get-PdbSignature $ntos
Write-Host "[*] kernel pdb $($info.Name) ($($info.Signature))"

$roots = @()
if ($env:ProgramData) { $roots += (Join-Path $env:ProgramData 'dbg\sym') }
if ($env:LOCALAPPDATA) { $roots += (Join-Path $env:LOCALAPPDATA 'dbg\sym') }
$url = "https://msdl.microsoft.com/download/symbols/$($info.Name)/$($info.Signature)/$($info.Name)"

foreach ($root in $roots) {
    $dir = Join-Path $root (Join-Path $info.Name $info.Signature)
    $file = Join-Path $dir $info.Name
    if (Test-Path $file) {
        if ((Get-Item $file).Length -gt 1000000) {
            Write-Host "[+] already cached: $file"
            exit 0
        }
        Remove-Item $file -Force -ErrorAction SilentlyContinue
    }
    try { New-Item -ItemType Directory -Force -Path $dir | Out-Null } catch { continue }
    Write-Host "[*] downloading to $file"
    if (Get-Remote $url $file) {
        Write-Host "[+] symbol file ready"
        exit 0
    }
}

Write-Host '[-] automatic download failed on every method'
Write-Host '[!] open this in a browser and save the file here:'
Write-Host "    $url"
foreach ($root in $roots) {
    Write-Host "    $(Join-Path $root (Join-Path $info.Name (Join-Path $info.Signature $info.Name)))"
    break
}
exit 1
